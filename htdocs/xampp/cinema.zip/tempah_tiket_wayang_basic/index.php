<?PHP 
# Memanggil fail header.php
include ('header.php');
# Memanggil fail connection.php
include ('connection.php');

#menyemak kewujuan data GET tarikh tayangan
if(empty($_GET))
{ $tarikh_pilihan=date("Y-m-d"); } 
else 
{ $tarikh_pilihan=$_GET['tarikh_pilihan']; }

# arahan SQL untuk memilih filem yang tarikh tamat > dari tarikh pilihan
$arahan_cari="select* from filem
where tarikh_tamat>='$tarikh_pilihan' order by tarikh_mula DESC";

# laksanakan arahan SQL
$laksana=mysqli_query($condb,$arahan_cari);
?>

<!-- borang untuk memasukan tarikh pilihan -->
<form action='' method='GET'>
  <p>Pilih tarikh tayangan</p>
  <input type='date' name='tarikh_pilihan' min='<?PHP echo date("Y-m-d"); ?>' value='<?PHP echo $tarikh_pilihan; ?>'>
  <button type='submit'>Papar</button>
</form>

<!-- jadual untuk memaparkan senarai filem yang ditayangkan pada tarikh pilihan -->
<table border='1'>
<?PHP 
$baris=0;

while($rekod=mysqli_fetch_array($laksana))
{
  # mengumpukan data yang diambil kepada tatasusunan
  $data_get= array(
    'tarikh_pilihan'=>$tarikh_pilihan,
    'id_filem'=>$rekod['id_filem'],
    'nama_filem'=>$rekod['nama_filem'],
    'tarikh_mula'=>$rekod['tarikh_mula'],
    'tarikh_tamat'=>$rekod['tarikh_tamat'],
    'gambar'=>$rekod['gambar'],
    'harga_dewasa'=>$rekod['harga_dewasa'],
    'harga_kanak'=>$rekod['harga_kanak'],
    'kategori'=>$rekod['kategori']
  );

  if($baris==0)
  { echo"<tr align='center'><td>"; }
  else if($baris==6)
  { echo"</tr><tr align='center'><td>"; $baris=0; }
  else
  { echo"</td> <td>"; }

# Memaparkan maklumat filem 
echo"<img src='images/movie/".$rekod['gambar']."' width='50%'>
<p>Kategori".$rekod['kategori']."</p>
<p><b>Berakhir pada : ".$rekod['tarikh_tamat']."</b></p>
<a href='filem_info.php?".http_build_query($data_get)."'>Tempah Sekarang</a>";

$baris++;
}
?>        
</table>        
<?PHP include ('footer.php'); ?>