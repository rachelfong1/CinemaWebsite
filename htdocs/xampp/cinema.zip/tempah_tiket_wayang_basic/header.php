<?PHP 
#Memulakan fungsi session
session_start(); 
#Set rujukkan zon masa & tarikh
date_default_timezone_set("Asia/Kuala_Lumpur");
?>

<!-- tajuk kepada sistem -->
<h1><b>Jom Layan Wayang</b></h1>
<i>Wayang dimana-mana bila-bila</i>
<hr>

<!-- Menu yang akan dipaparkan kepada semua pengguna -->
| <a href="index.php">Laman Utama</a>

<!-- menyemak kewujudan session nama_pelanggan (jika telah login, maka session ini akan mempunyai nilai) -->
<?PHP if(empty($_SESSION['nama_pelanggan'])) { ?>

<!-- Menu yang akan dipaparkan kepada pengguna yang belum login-->
| <a href="pelanggan_login.php">Daftar Masuk Ahli</a>
| <a href="pelanggan_daftar.php">Daftar Ahli baru</a> |
  
<?PHP } else { ?>

<!-- Menu yang akan dipaparkan kepada pengguna yang telah login-->
| <a href="logout.php">Logout</a> |
  
<?PHP } ?>

<hr>
