<!--Memanggil fail header-->
<?PHP include('header.php'); ?>

<!--Menyediakan form bagi daftar masuk pengguna-->
<h4>Daftar Masuk Pengguna</h4>
<form action='' method='POST' autofocus>
Nokp Pengguna   <input type='text' name='nokp'><br>
Katalaluan      <input type='password' name='katalaluan'><br>
                <input type='submit' value='Daftar Masuk'>
</form>

 <!-- Memanggil fail footer-->
 <?PHP include('footer.php'); ?>

<?PHP 
# menyemak kewujudan data POST
if (!empty($_POST))
{
    # memanggil fail connection
    include ('connection.php');

    # mengambil data POST
    $nokp=$_POST['nokp'];
    $katalaluan=$_POST['katalaluan'];

    # arahan SQL untuk mencari data dari jadual pelanggan
    $arahan_sql_cari="select* 
    from pelanggan 
    where nokp_pelanggan='$nokp' and 
    katalaluan_pelanggan='$katalaluan'
    limit 1 ";

    # melaksanakan proses carian 
    $laksana_arahan=mysqli_query($condb,$arahan_sql_cari);

    # jika terdapat 1 baris rekod di temui
    if(mysqli_num_rows($laksana_arahan)==1)
    {
        # login berjaya
        # pembolehubah $rekod mengambil data yang di temui semasa proses mencari
        $rekod=mysqli_fetch_array($laksana_arahan);

        #mengumpukkan kepada pembolehubah session
        $_SESSION['nama_pelanggan']=$rekod['nama_pelanggan'];
        $_SESSION['nokp_pelanggan']=$rekod['nokp_pelanggan'];
        $_SESSION['notel_pelanggan']=$rekod['notel_pelanggan'];
        
        # mengarahkan fail index.php dibuka
        echo "<script>window.location.href='index.php';</script>";
    }
    else
    {
        # login gagal. kembali ke laman sebelumnya
        echo "<script>alert('login gagal');
        window.history.back();</script>";
    }
}
?>