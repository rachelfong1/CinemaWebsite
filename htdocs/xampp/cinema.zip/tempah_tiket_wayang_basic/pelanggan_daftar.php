<!-- Memanggil fail header-->
<?PHP include('header.php'); ?>

<!-- Menyediakan borang untuk mendaftar pelanggan baru-->
<h4>Daftar Masuk ahli</h4>
<form action='' method='POST'>
Nama ahli         <input type='text' name='nama'><br>
Nokp ahli         <input type='text' name='nokp'><br>
No Tel ahli       <input type='text' name='notel'><br>
Katalaluan ahli   <input type='password' name='katalaluan'><br>
                  <input type='submit' value='Daftar ahli'>
</form>

 <!-- Memanggil fail footer-->
<?PHP include('footer.php'); ?>

<?PHP 
# menyemak kewujudan data POST
if (!empty($_POST))
{
    # memanggil fail connection
    include ('connection.php');

    # mengambil data POST
    $nama=$_POST['nama'];
    $notel=$_POST['notel'];
    $nokp=$_POST['nokp'];
    $katalaluan=$_POST['katalaluan'];

    # -- data validation --
    if(empty($nama) or empty($notel) or empty($nokp) or empty($katalaluan))
    {
        die("<script>alert('Lengkapkan maklumat yang dikehendaki.');
        window.history.back();</script>");
    }

    # --- data validation bilangan nokp dan semak aksara
    if(strlen($nokp)!=12 or !is_numeric($nokp))
    {
        die("<script>alert('Ralat pada nokp');
        window.history.back();</script>");
    }
 
    # arahan SQL untuk menyimpan data ke dalam jadual pelanggan
    $arahan_sql_simpan="insert into pelanggan
    (nama_pelanggan,nokp_pelanggan,notel_pelanggan,katalaluan_pelanggan)
    values
    ('$nama','$nokp','$notel','$katalaluan')";

    # melaksanakan proses menyimpan dalam syarat if
    if(mysqli_query($condb,$arahan_sql_simpan))
    {
        # jika proses menyimpan berjaya. papar info dan buka laman pelanggan_login.php
        echo "<script>alert('Pendaftaran Berjaya');
        window.location.href='pelanggan_login.php';</script>";
    }
    else
    {
        # jika proses menyimpan gagal, kembali ke laman sebelumnya
        echo "<script>alert('Pendaftaran gagal');
        window.history.back();</script>";
    }
}
?>