<?PHP 

$condb=mysqli_connect('localhost','root','root123','tempah_tiket_wayang')

?>