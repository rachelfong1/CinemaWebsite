<?PHP
# memulakan fungsi session 
session_start(); 

#----------------- Bahagian login & logout Session ------------
if(empty($_SESSION['nokp_admin']))
{
    die("<script>alert('Sila daftar Masuk');
    window.location.href='index.php';</script>");
}
date_default_timezone_set("Asia/Kuala_Lumpur");
?>

<!-- Kod Javascript untuk membesarkan saiz tulisan-->
<script>
function resizeText(multiplier) {
    var elem = document.getElementById("saiz");
    var currentSize = elem.style.fontSize || 1;
    if(multiplier==2)
    {
        elem.style.fontSize = "1em";
    } 
    else 
    {
        elem.style.fontSize = ( parseFloat(currentSize) + (multiplier * 0.2)) + "em";
    }
}
</script>

<!-- Tajuk Sistem admin-->
<h1><b>Jom Layan Wayang</b></h1>
<hr>

<!-- Menu -->
  | <a href="laman_utama.php">Laman Utama</a>
  | <a href="maklumat_pelanggan.php">Maklumat Pelanggan</a>
  | <a href="maklumat_filem.php">Maklumat Filem</a>
  | <a href="maklumat_tayangan.php">Maklumat Tayangan</a>
  | <a href="maklumat_tempahan.php">Maklumat Tempahan</a>
  | <a href="maklumat_admin.php">Maklumat Admin</a>
  | <a href="analisis.php">Analisis</a>
  | <a href="upload.php" >Upload Tayangan</a>
  | <a href="../logout.php?id=admin">Logout</a> | 
<hr>