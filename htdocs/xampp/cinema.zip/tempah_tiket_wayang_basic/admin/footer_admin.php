<hr>
<div>
    <p>Hak Cipta Terpelihara</p>
</div>
</body>
</html>