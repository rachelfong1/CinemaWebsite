<?PHP 
session_start(); 
date_default_timezone_set("Asia/Kuala_Lumpur");
?>
<!DOCTYPE html>
<html>
<head>
<title>Tempah Tiket Wayang</title>
</head>
<body>

<h1><b>Jom Layan Wayang</b></h1>
<i>Wayang dimana-mana bila-bila</i>
<hr>
<center>
    <h2 ><b>Administrator</b></h2>
    <p>Sila daftar Masuk</p>
    <p ><i>Jangan dedahkan katalaluan anda kepada orang lain</i></p>
    <p ><i>Tukar katalaluan anda secara berkala</i></p>

  <form action='' method='POST'>
    Nokp Pengguna 
    <input type='text' name='nokp' autofocus><br>
    Katalaluan 
    <input type='password' name='katalaluan'><br>
    <input type='submit' value='Daftar Masuk'>
    </form>







    </center>

</body>
</html>

<?PHP 
# menyemak kewujudan data POST
if (!empty($_POST))
{
    # memanggil fail connection
    include ('../connection.php');

    # mengambil data POST
    $nokp=$_POST['nokp'];
    $katalaluan=$_POST['katalaluan'];

    # arahan SQL untuk mencari data dari jadual admin
    $arahan_sql_cari="select* 
    from admin 
    where nokp_admin='$nokp' and 
    katalaluan_admin='$katalaluan'
    limit 1 ";

    # melaksanakan proses carian 
    $laksana_arahan=mysqli_query($condb,$arahan_sql_cari);

    # jika terdapat 1 baris rekod di temui
    if(mysqli_num_rows($laksana_arahan)==1)
    {
        # login berjaya
        # pembolehubah $rekod mengambil data yang di temui semasa proses mencari
        $rekod=mysqli_fetch_array($laksana_arahan);

        #mengumpukkan kepada pembolehubah session
        $_SESSION['nama_admin']=$rekod['nama_admin'];
        $_SESSION['nokp_admin']=$rekod['nokp_admin'];
        
        # mengarahkan fail index.php dibuka
        echo "<script>window.location.href='laman_utama.php';</script>";
    }
    else
    {
        # login gagal. kembali ke laman sebelumnya
        echo "<script>alert('login gagal');
        window.history.back();</script>";
    }
}
?>